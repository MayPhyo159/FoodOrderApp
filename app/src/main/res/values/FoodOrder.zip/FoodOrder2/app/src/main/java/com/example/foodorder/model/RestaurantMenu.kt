package com.example.foodorder.model

data class RestaurantMenu (
    var id:String,
    var name:String,
    var cost_for_one:String
)